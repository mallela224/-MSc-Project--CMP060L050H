from django.apps import AppConfig


class SellersConfig(AppConfig):
    name = 'sellers'
