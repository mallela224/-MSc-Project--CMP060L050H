import json
import os
from web3 import Web3
from web3 import Account

# Set up web3 connection (Ganache default)
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

# Path to compiled contract ABI and bytecode (to be generated after compiling the Solidity contract)
CONTRACT_ABI_PATH = os.path.join(os.path.dirname(__file__), '../../blockchain/contracts/TransactionRecord_abi.json')
CONTRACT_BYTECODE_PATH = os.path.join(os.path.dirname(__file__), '../../blockchain/contracts/TransactionRecord_bytecode.txt')
CONTRACT_ADDRESS_PATH = os.path.join(os.path.dirname(__file__), '../../blockchain/contracts/TransactionRecord_address.txt')


def load_contract():
    with open(CONTRACT_ABI_PATH, 'r') as abi_file:
        abi = json.load(abi_file)
    with open(CONTRACT_ADDRESS_PATH, 'r') as addr_file:
        address = addr_file.read().strip()
    contract = w3.eth.contract(address=address, abi=abi)
    return contract


def record_transaction(buyer, seller, details, private_key):
    contract = load_contract()
    account = Account.from_key(private_key)
    nonce = w3.eth.get_transaction_count(account.address)
    txn = contract.functions.recordTransaction(buyer, seller, details).build_transaction({
        'from': account.address,
        'nonce': nonce,
        'gas': 3000000,
        'gasPrice': w3.to_wei('20', 'gwei')
    })
    signed_txn = w3.eth.account.sign_transaction(txn, private_key=private_key)
    tx_hash = w3.eth.send_raw_transaction(signed_txn.raw_transaction)
    return tx_hash.hex()


def get_transaction(tx_id):
    contract = load_contract()
    return contract.functions.getTransaction(tx_id).call()


def get_all_transactions():
    contract = load_contract()
    return contract.functions.getAllTransactions().call() 